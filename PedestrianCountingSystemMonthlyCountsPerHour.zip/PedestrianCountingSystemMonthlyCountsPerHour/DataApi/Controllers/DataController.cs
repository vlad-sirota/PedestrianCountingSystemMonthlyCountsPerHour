﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;

namespace DataApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class DataController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<DataController> _logger;
        private string _sqlServerConnectionString;

        public DataController(ILogger<DataController> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
            _sqlServerConnectionString = _configuration.GetConnectionString("SQLServer");
        }

        [HttpGet]
        [Route("ingestionStatus")]
        public IActionResult GetIngestionStatus()
        {
            try
            {
                var ingestionStatus = "No status available";

                using (SqlConnection connection = new SqlConnection(_sqlServerConnectionString))
                {
                    connection.Open();

                    var sqlText = "SELECT TOP 1 Status FROM IngestionStatus ORDER BY IngestionDateTime DESC";

                    using (SqlCommand command = new SqlCommand(sqlText, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                ingestionStatus = reader.GetString(0);
                            }
                        }
                    }
                }
                
                return Ok(ingestionStatus);
            }
            catch (Exception e)
            {
                // log exception
                _logger.LogError(e, "Error occurred in GetIngestionStatus action", null);

                return BadRequest();
            }
        }

        [HttpGet]
        [Route("averageHourlyFootfallCount")]
        public IActionResult GetAverageHourlyFootfallCount()
        {
            try
            {
                var averageHourlyFootfallCount = new List<AverageHourlyFootfall>();

                using (SqlConnection connection = new SqlConnection(_sqlServerConnectionString))
                {
                    connection.Open();

                    // stored proc
                    var sqlText = "exec [dbo].[Calculate_Average_Hourly_Footfall]";

                    using (SqlCommand command = new SqlCommand(sqlText, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var item = new AverageHourlyFootfall
                                {
                                    AverageHourlyFootfallCount = reader.GetInt32(0),
                                    SensorId = reader.GetInt32(1),
                                    SensorDate =  reader.GetDateTime(2)
                                };
                                averageHourlyFootfallCount.Add(item);
                            }
                        }
                    }
                }

                return averageHourlyFootfallCount.Count > 0 ? Ok(averageHourlyFootfallCount) : Ok("No data available!");
            }
            catch (Exception e)
            {
                // log exception
                _logger.LogError(e, "Error occurred in GetAverageHourlyFootfallCount action", null);

                return BadRequest();
            }
        }
    }
}