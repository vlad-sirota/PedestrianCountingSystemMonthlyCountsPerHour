﻿using System;

namespace DataApi
{
    public class AverageHourlyFootfall
    {
        public int AverageHourlyFootfallCount { get; set; }

        public int SensorId { get; set; }

        public DateTime SensorDate { get; set; }
    }
}
