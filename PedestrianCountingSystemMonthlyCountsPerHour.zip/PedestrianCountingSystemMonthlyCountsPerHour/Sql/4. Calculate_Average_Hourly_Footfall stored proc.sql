USE [PedestrianCountingSystemDB]
GO

/****** Object:  StoredProcedure [dbo].[Calculate_Average_Hourly_Footfall]    Script Date: 18/09/2022 9:28:35 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Vlad Sirota
-- Create date: 18.09.2202
-- Description:	Calculates the average hourly footfall count by sensor and date
--              and stores this calculated data into a table to make it available 
--              for query by other applications. At the end, the data is also returned
-- =============================================
CREATE PROCEDURE [dbo].[Calculate_Average_Hourly_Footfall] 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	TRUNCATE TABLE [dbo].[AverageHourlyFootfall];

	INSERT INTO [dbo].[AverageHourlyFootfall]
	SELECT AVG(HourlyCounts), SensorId, CAST([DateTime] as DATE)
	FROM [dbo].[PedestrianCountingSystemMonthlyCountsPerHour]
	GROUP BY SensorId, CAST([DateTime] as DATE);
	
	SELECT AverageHourlyFootfallCount, SensorId, SensorDate
	FROM [dbo].[AverageHourlyFootfall]
	ORDER BY SensorId, SensorDate
END
GO


