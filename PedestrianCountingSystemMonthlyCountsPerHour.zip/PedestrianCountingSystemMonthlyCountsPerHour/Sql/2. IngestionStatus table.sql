CREATE TABLE [dbo].[IngestionStatus] (
   [Id] [int] IDENTITY(1,1) PRIMARY KEY,
   [IngestionDateTime] datetime DEFAULT GETDATE(),
   [Status] [varchar](25) NULL
)

