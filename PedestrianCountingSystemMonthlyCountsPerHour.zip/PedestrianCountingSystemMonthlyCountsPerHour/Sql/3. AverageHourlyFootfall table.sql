CREATE TABLE [dbo].[AverageHourlyFootfall] (
   [AverageHourlyFootfallCount] [int],
   [SensorId]  [int],
   [SensorDate] [datetime]
)

