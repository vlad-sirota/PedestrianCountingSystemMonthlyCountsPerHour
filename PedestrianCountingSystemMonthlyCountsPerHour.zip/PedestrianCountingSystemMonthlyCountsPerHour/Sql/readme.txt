Please create a database in SQL Server called PedestrianCountingSystemDB.

Then please run all the scripts in order from 1 to 4.