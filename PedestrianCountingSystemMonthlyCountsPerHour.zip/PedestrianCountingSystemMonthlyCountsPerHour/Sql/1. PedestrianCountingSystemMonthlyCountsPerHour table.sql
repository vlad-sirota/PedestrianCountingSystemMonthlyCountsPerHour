CREATE TABLE [dbo].[PedestrianCountingSystemMonthlyCountsPerHour] (
   [Id] [BigInt],
   [DateTime] datetime,
   [Year] [int],
   [Month] [varchar](10) NULL,
   [Mdate] [int],
   [Day] [varchar](10) NULL,
   [Time] [int],
   [SensorId] [int],
   [SensorName] [varchar](50) NULL,
   [HourlyCounts] [int]
)	