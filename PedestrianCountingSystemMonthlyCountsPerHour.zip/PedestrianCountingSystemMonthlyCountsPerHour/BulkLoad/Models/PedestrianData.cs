﻿using CsvHelper.Configuration.Attributes;

namespace PedestrianCountingSystemMonthlyCountsPerHour.Models
{
    public class PedestrianData
    {
        private string hourlyCounts;

        [Index(0)]
        public int Id { get; set; }

        [Index(1)]
        public string DateTime { get; set; }

        [Index(2)]
        public int Year { get; set; }

        [Index(3)]
        public string Month { get; set;}

        [Index(4)]
        public int Mdate { get; set; }

        [Index(5)]
        public string Day { get; set; }

        [Index(6)]
        public int Time { get; set; }

        [Index(7)]
        public int SensorId { get; set; }

        [Index(8)]
        public string SensorName { get; set; }

        [Index(9)]
        public string HourlyCounts 
        { 
            get { return hourlyCounts; }
            set 
            {
                hourlyCounts = ReplaceComma(value);
            }
        }

        public static string ReplaceComma(string hourlyCounts)
        {
            if (hourlyCounts.IndexOf(",") != -1)
            {
                return hourlyCounts.Replace(",", "");
            }

            return hourlyCounts;
        }
    }
}
