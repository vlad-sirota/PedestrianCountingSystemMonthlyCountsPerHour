﻿using CsvHelper;
using CsvHelper.Configuration;
using PedestrianCountingSystemMonthlyCountsPerHour.Models;
using PedestrianCountingSystemMonthlyCountsPerHour.Helpers;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Configuration;

namespace PedestrianCountingSystemMonthlyCountsPerHour
{
	class Program
    {
		private static string _connectionString = ConfigurationManager.ConnectionStrings["sqlServerConnection"].ToString();

		static void Main(string[] args)
        {
			try
			{
				ClearIngestionStatus();
				LoadData();
			}
			catch (Exception e)
			{
				// log exception
				LogError(e);
			}
        }

		public static void LoadData()
		{
			var dataFilePath = Path.GetFullPath(ConfigurationManager.AppSettings["dataFilePath"].ToString());
			var destinationTableName = ConfigurationManager.AppSettings["destinationTableName"].ToString();
			
			IEnumerable<PedestrianData> records = new List<PedestrianData>();

			var configuration = new CsvConfiguration(CultureInfo.InvariantCulture)
			{
				HasHeaderRecord = true,
			};

			WriteStatus("Opening file");

			using (var reader = new StreamReader(dataFilePath))
			using (var csv = new CsvReader(reader, configuration))
			{
				WriteStatus("Reading from file");

				records = csv.GetRecords<PedestrianData>();

				var recordsRead = records.ToList();
				if (recordsRead.Count == 0)
					throw new Exception("File empty - No records found!");

				using (var copy = new SqlBulkCopy(_connectionString))
				{
					WriteStatus("Loading data");

					copy.DestinationTableName = destinationTableName;
					
					// Add mappings
					copy.ColumnMappings.Add("Id", "Id");
					copy.ColumnMappings.Add("DateTime", "DateTime");
					copy.ColumnMappings.Add("Year", "Year");
					copy.ColumnMappings.Add("Month", "Month");
					copy.ColumnMappings.Add("Mdate", "Mdate");
					copy.ColumnMappings.Add("Day", "Day");
					copy.ColumnMappings.Add("Time", "Time");
					copy.ColumnMappings.Add("SensorId", "SensorId");
					copy.ColumnMappings.Add("SensorName", "SensorName");
					copy.ColumnMappings.Add("HourlyCounts", "HourlyCounts");

					copy.WriteToServer(DataTableHelper.ToDataTable(recordsRead));
				}

				WriteStatus("Finished loading data");
				Console.WriteLine("Press any key to exit...");
				Console.ReadLine();
			}
		}

		public static void ClearIngestionStatus()
		{
			// Clear Ingestion Status table
			using (SqlConnection connection = new SqlConnection(_connectionString))
			{
				var query = "DELETE FROM [dbo].[IngestionStatus];";

				using (SqlCommand command = new SqlCommand(query, connection))
				{
					connection.Open();
					int result = command.ExecuteNonQuery();

					// Check Error
					if (result < 0)
					{
						Console.WriteLine("Error clearing IngestionStatus table!");
						throw new Exception("Error clearing IngestionStatus table!");
					}
				}
			}
		}

		public static void WriteStatus(string status)
		{
			Console.WriteLine($"{status}...");

			// Update Ingestion Status table
			using (SqlConnection connection = new SqlConnection(_connectionString))
			{
				var query = "INSERT INTO IngestionStatus (Status) VALUES (@status)";

				using (SqlCommand command = new SqlCommand(query, connection))
				{
					command.Parameters.AddWithValue("@status", status);

					connection.Open();
					int result = command.ExecuteNonQuery();

					// Check Error
					if (result < 0)
					{
						Console.WriteLine("Error inserting data into IngestionStatus table!");
						throw new Exception("Error inserting data into IngestionStatus table!");
					}
				}
			}
		}

		public static void LogError(Exception exception)
		{
			var errorFilePath = Path.GetFullPath(ConfigurationManager.AppSettings["errorFilePath"].ToString());
			var errorMessage = $"Exception occurred: {exception.StackTrace}";

			Console.WriteLine(errorMessage);

			using (StreamWriter writer = new StreamWriter(errorFilePath))
			{
				writer.WriteLine(errorMessage);
			}
		}
	}
}
